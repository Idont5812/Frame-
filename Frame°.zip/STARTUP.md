
# Frame° — Startup Procedure

This guide explains how to install, configure, and start Frame° locally.

## 1. Requirements

- Node.js 20 or newer
- npm
- Frame° project files
- Termux (Android), Linux, or macOS

### Termux dependencies

```bash
pkg update
pkg install nodejs-lts python make clang pkg-config
```

`better-sqlite3` is a native dependency. If installation fails on Termux, check the build error before continuing.

## 2. Project structure

Run all commands from the folder containing `package.json`.

```text
frame/
├── package.json
├── vite.config.js
├── .env
├── start.sh
├── STARTUP-PROCEDURE.md
├── index.html
├── pages/
├── src/
└── server/
    ├── db.js
    ├── index.js
    └── uploads/
        ├── videos/
        └── thumbnails/
```

## 3. First-time startup

Make the script executable:

```bash
chmod +x start.sh
```

Start Frame°:

```bash
./start.sh
```

The script automatically:

1. Checks Node.js and npm.
2. Creates `.env` if it doesn't exist.
3. Generates a secure random JWT secret if needed.
4. Installs dependencies if `node_modules` is missing.
5. Starts the frontend and backend together.

## 4. Access Frame°

Once started, open:

**Frontend:** http://localhost:5173/

**API health check:** http://localhost:3000/api/health

Keep the terminal running while using the application.

Press `Ctrl+C` to stop the development servers.

## 5. Useful commands

```bash
# Start frontend and backend
npm run dev

# Start only frontend
npm run client

# Start only backend
npm run server

# Build frontend for production
npm run build
```

## 6. Database

Frame° uses SQLite.

The database is automatically created at:

```text
server/frame.db
```

Back up this file regularly if you want to preserve accounts, videos, likes, and starred videos.

Uploaded files are stored in:

```text
server/uploads/videos/
server/uploads/thumbnails/
```

## 7. Troubleshooting

### Node.js not found

```bash
pkg install nodejs-lts
```

### Dependency installation fails

On Termux, install build tools:

```bash
pkg install python make clang pkg-config
```

Then retry:

```bash
npm install
```

### Port already in use

Another process may already be using port `5173` or `3000`. Stop the previous Frame° process before restarting.

### API not responding

Check:

```text
http://localhost:3000/api/health
```

Make sure the backend started without errors.

### JWT configuration error

Check that `.env` contains a non-empty `JWT_SECRET`. Restart Frame° after changing it.

### Uploads not working

Ensure the server can write to:

```text
server/uploads/videos/
server/uploads/thumbnails/
```

## 8. Important deployment notes

This configuration is intended for development.

Before exposing Frame° publicly, configure:

- HTTPS
- Secure production cookies
- Upload validation and size limits
- Rate limiting
- Database backups
- Production server hosting

The password-reset page is currently a UI placeholder unless an email/reset service is configured separately.
