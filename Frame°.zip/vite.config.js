import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { resolve } from "path";

export default defineConfig({
  plugins: [react()],
  server: {
    host: "0.0.0.0",
    port: 5173,
    allowedHosts: ["frame.shares.zrok.io"], // Or use [".zrok.io"] for any zrok subdomain
    proxy: {
      "/api": "http://localhost:3000",
      "/uploads": "http://localhost:3000"
    }
  },
  build: {
    rollupOptions: {
      input: {
        home: resolve(__dirname, "index.html"),
        watch: resolve(__dirname, "pages/watch.html"),
        login: resolve(__dirname, "pages/login.html"),
        signup: resolve(__dirname, "pages/signup.html"),
        forgot: resolve(__dirname, "pages/forgot.html"),
        upload: resolve(__dirname, "pages/upload.html"),
        starred: resolve(__dirname, "pages/starred.html"),
        account: resolve(__dirname, "pages/account.html")
      }
    }
  }
});

