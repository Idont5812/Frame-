import "dotenv/config";
import express from "express";
import cookieParser from "cookie-parser";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import multer from "multer";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import db from "./db.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const SECRET = process.env.JWT_SECRET;

if (!SECRET || SECRET.length < 24) {
  throw new Error("Set JWT_SECRET to a random secret of at least 24 characters in .env");
}

const videoDir = path.join(__dirname, "uploads/videos");
const thumbDir = path.join(__dirname, "uploads/thumbnails");

fs.mkdirSync(videoDir, { recursive: true });
fs.mkdirSync(thumbDir, { recursive: true });

app.use(express.json({ limit: "2mb" }));
app.use(cookieParser());
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, file.fieldname === "thumbnail" ? thumbDir : videoDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase().replace(/[^.a-z0-9]/g, "");
    cb(null, `${Date.now()}-${Math.random().toString(36).slice(2)}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: {
    fileSize: 1024 * 1024 * 1024,
    files: 2
  },
  fileFilter: (req, file, cb) => {
    const isVideo = file.fieldname === "video" && file.mimetype.startsWith("video/");
    const isImage = file.fieldname === "thumbnail" && file.mimetype.startsWith("image/");
    cb(isVideo || isImage ? null : new Error("Unsupported file type."), isVideo || isImage);
  }
});

function publicUser(user) {
  return user ? {
    id: user.id,
    name: user.name,
    email: user.email,
    createdAt: user.created_at
  } : null;
}

function makeToken(user) {
  return jwt.sign({ id: user.id }, SECRET, { expiresIn: "7d" });
}

function setSession(res, user) {
  res.cookie("frame_session", makeToken(user), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: "/"
  });
}

function auth(req, res, next) {
  try {
    const token = req.cookies.frame_session;
    if (!token) return res.status(401).json({ error: "Please sign in first." });

    const payload = jwt.verify(token, SECRET);
    const user = db.prepare("SELECT id, name, email, created_at FROM users WHERE id = ?")
      .get(payload.id);

    if (!user) return res.status(401).json({ error: "Session is no longer valid." });

    req.user = user;
    next();
  } catch {
    res.status(401).json({ error: "Please sign in again." });
  }
}

function videoData(row, userId = null) {
  if (!row) return null;

  const likes = db.prepare("SELECT COUNT(*) AS count FROM likes WHERE video_id = ?").get(row.id).count;
  const views = db.prepare("SELECT COUNT(*) AS count FROM views WHERE video_id = ?").get(row.id).count;

  const liked = userId
    ? !!db.prepare("SELECT 1 FROM likes WHERE user_id = ? AND video_id = ?").get(userId, row.id)
    : false;

  const starred = userId
    ? !!db.prepare("SELECT 1 FROM stars WHERE user_id = ? AND video_id = ?").get(userId, row.id)
    : false;

  return {
    id: row.id,
    title: row.title,
    description: row.description,
    videoUrl: row.video_path,
    thumbnail: row.thumbnail_path,
    duration: row.duration || "0:00",
    uploader: row.uploader || "Frame° creator",
    uploaderName: row.uploader || "Frame° creator",
    uploadedAt: row.created_at,
    likes,
    views,
    liked,
    starred
  };
}

function getVideo(id, userId = null) {
  const row = db.prepare(`
    SELECT videos.*, users.name AS uploader
    FROM videos JOIN users ON users.id = videos.user_id
    WHERE videos.id = ?
  `).get(id);

  return videoData(row, userId);
}

app.get("/api/health", (req, res) => {
  res.json({ ok: true, service: "Frame° API" });
});

/* Authentication */

app.post("/api/auth/register", async (req, res) => {
  try {
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");

    if (name.length < 1 || name.length > 40) {
      return res.status(400).json({ error: "Name must be 1–40 characters." });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ error: "Enter a valid email address." });
    }
    if (password.length < 8 || password.length > 128) {
      return res.status(400).json({ error: "Password must be 8–128 characters." });
    }

    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare(
      "INSERT INTO users (name, email, password) VALUES (?, ?, ?)"
    ).run(name, email, hash);

    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(result.lastInsertRowid);
    setSession(res, user);
    res.status(201).json({ user: publicUser(user) });
  } catch (err) {
    if (err.code === "SQLITE_CONSTRAINT_UNIQUE") {
      return res.status(409).json({ error: "An account with that email already exists." });
    }
    res.status(500).json({ error: "Could not create account." });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);

  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(401).json({ error: "Incorrect email or password." });
  }

  setSession(res, user);
  res.json({ user: publicUser(user) });
});

app.get("/api/auth/me", (req, res) => {
  try {
    const token = req.cookies.frame_session;
    if (!token) return res.json({ user: null });

    const payload = jwt.verify(token, SECRET);
    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(payload.id);
    res.json({ user: publicUser(user) });
  } catch {
    res.json({ user: null });
  }
});

app.post("/api/auth/logout", (req, res) => {
  res.clearCookie("frame_session", { path: "/" });
  res.json({ ok: true });
});

/* Video catalogue and search */

app.get("/api/videos", (req, res) => {
  const search = String(req.query.search || "").trim();
  const query = search
    ? db.prepare(`
        SELECT videos.*, users.name AS uploader
        FROM videos JOIN users ON users.id = videos.user_id
        WHERE videos.title LIKE ? OR videos.description LIKE ? OR users.name LIKE ?
        ORDER BY videos.created_at DESC LIMIT 100
      `).all(`%${search}%`, `%${search}%`, `%${search}%`)
    : db.prepare(`
        SELECT videos.*, users.name AS uploader
        FROM videos JOIN users ON users.id = videos.user_id
        ORDER BY videos.created_at DESC LIMIT 100
      `).all();

  const userId = (() => {
    try {
      return jwt.verify(req.cookies.frame_session || "", SECRET).id;
    } catch {
      return null;
    }
  })();

  res.json({ videos: query.map((row) => videoData(row, userId)) });
});

app.get("/api/videos/:id", (req, res) => {
  const id = Number(req.params.id);
  const video = getVideo(id);

  if (!video) return res.status(404).json({ error: "Video not found." });

  let userId = null;
  try {
    userId = jwt.verify(req.cookies.frame_session || "", SECRET).id;
  } catch {}

  const fullVideo = getVideo(id, userId);

  db.prepare("INSERT INTO views (video_id, user_id) VALUES (?, ?)").run(
    id,
    userId || null
  );

  const relatedRows = db.prepare(`
    SELECT videos.*, users.name AS uploader
    FROM videos JOIN users ON users.id = videos.user_id
    WHERE videos.id != ?
    ORDER BY videos.created_at DESC LIMIT 6
  `).all(id);

  res.json({
    video: { ...fullVideo, views: fullVideo.views + 1 },
    related: relatedRows.map((row) => videoData(row, userId))
  });
});

/* Likes and stars */

app.post("/api/videos/:id/like", auth, (req, res) => {
  const id = Number(req.params.id);
  if (!db.prepare("SELECT id FROM videos WHERE id = ?").get(id)) {
    return res.status(404).json({ error: "Video not found." });
  }

  const existing = db.prepare(
    "SELECT 1 FROM likes WHERE user_id = ? AND video_id = ?"
  ).get(req.user.id, id);

  if (existing) {
    db.prepare("DELETE FROM likes WHERE user_id = ? AND video_id = ?").run(req.user.id, id);
  } else {
    db.prepare("INSERT INTO likes (user_id, video_id) VALUES (?, ?)").run(req.user.id, id);
  }

  res.json({ video: getVideo(id, req.user.id) });
});

app.post("/api/videos/:id/star", auth, (req, res) => {
  const id = Number(req.params.id);
  if (!db.prepare("SELECT id FROM videos WHERE id = ?").get(id)) {
    return res.status(404).json({ error: "Video not found." });
  }

  const existing = db.prepare(
    "SELECT 1 FROM stars WHERE user_id = ? AND video_id = ?"
  ).get(req.user.id, id);

  if (existing) {
    db.prepare("DELETE FROM stars WHERE user_id = ? AND video_id = ?").run(req.user.id, id);
  } else {
    db.prepare("INSERT INTO stars (user_id, video_id) VALUES (?, ?)").run(req.user.id, id);
  }

  res.json({ video: getVideo(id, req.user.id) });
});

app.get("/api/users/me/starred", auth, (req, res) => {
  const rows = db.prepare(`
    SELECT videos.*, users.name AS uploader
    FROM stars
    JOIN videos ON videos.id = stars.video_id
    JOIN users ON users.id = videos.user_id
    WHERE stars.user_id = ?
    ORDER BY videos.created_at DESC
  `).all(req.user.id);

  res.json({ videos: rows.map((row) => videoData(row, req.user.id)) });
});

/* Uploads and creator library */

app.post(
  "/api/videos",
  auth,
  upload.fields([
    { name: "video", maxCount: 1 },
    { name: "thumbnail", maxCount: 1 }
  ]),
  (req, res) => {
    const videoFile = req.files?.video?.[0];
    const thumbnailFile = req.files?.thumbnail?.[0];
    const title = String(req.body.title || "").trim();
    const description = String(req.body.description || "").trim();

    if (!videoFile) return res.status(400).json({ error: "Select a video file." });
    if (!title || title.length > 120) {
      fs.unlinkSync(videoFile.path);
      if (thumbnailFile) fs.unlinkSync(thumbnailFile.path);
      return res.status(400).json({ error: "Title must be 1–120 characters." });
    }

    const result = db.prepare(`
      INSERT INTO videos (user_id, title, description, video_path, thumbnail_path)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      req.user.id,
      title,
      description.slice(0, 3000),
      `/uploads/videos/${path.basename(videoFile.path)}`,
      thumbnailFile ? `/uploads/thumbnails/${path.basename(thumbnailFile.path)}` : null
    );

    res.status(201).json({ video: getVideo(result.lastInsertRowid, req.user.id) });
  }
);

app.delete("/api/videos/:id", auth, (req, res) => {
  const id = Number(req.params.id);
  const row = db.prepare("SELECT * FROM videos WHERE id = ? AND user_id = ?")
    .get(id, req.user.id);

  if (!row) return res.status(404).json({ error: "Your video was not found." });

  for (const file of [row.video_path, row.thumbnail_path]) {
    if (file?.startsWith("/uploads/")) {
      const fullPath = path.join(__dirname, file.replace("/uploads/", "uploads/"));
      if (fs.existsSync(fullPath)) fs.unlinkSync(fullPath);
    }
  }

  db.prepare("DELETE FROM videos WHERE id = ?").run(id);
  res.json({ ok: true });
});

/* Account */

app.get("/api/users/me", auth, (req, res) => {
  const uploads = db.prepare(
    "SELECT COUNT(*) AS count FROM videos WHERE user_id = ?"
  ).get(req.user.id).count;

  const starred = db.prepare(
    "SELECT COUNT(*) AS count FROM stars WHERE user_id = ?"
  ).get(req.user.id).count;

  const views = db.prepare(`
    SELECT COUNT(views.id) AS count
    FROM views JOIN videos ON videos.id = views.video_id
    WHERE videos.user_id = ?
  `).get(req.user.id).count;

  res.json({
    user: publicUser(req.user),
    stats: { uploads, starred, views }
  });
});

app.patch("/api/users/me", auth, (req, res) => {
  const name = String(req.body.name || "").trim();

  if (!name || name.length > 40) {
    return res.status(400).json({ error: "Name must be 1–40 characters." });
  }

  db.prepare("UPDATE users SET name = ? WHERE id = ?").run(name, req.user.id);
  const updated = db.prepare("SELECT * FROM users WHERE id = ?").get(req.user.id);

  res.json({ user: publicUser(updated) });
});

/* Error handling */

app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    const message = err.code === "LIMIT_FILE_SIZE"
      ? "File is too large. Maximum upload size is 1 GB."
      : err.message;
    return res.status(400).json({ error: message });
  }

  console.error(err);
  res.status(400).json({ error: err.message || "Request failed." });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Frame° API running on port ${PORT}`);
});