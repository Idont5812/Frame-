const API_BASE = "/api";

async function request(path, options = {}) {
  const isFormData = options.body instanceof FormData;

  const response = await fetch(`${API_BASE}${path}`, {
    credentials: "include",
    headers: {
      ...(isFormData ? {} : { "Content-Type": "application/json" }),
      ...options.headers
    },
    ...options
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.error || data.message || "Something went wrong.");
  }

  return data;
}

export const api = {
  // Authentication
  me: () => request("/auth/me"),
  login: (email, password) =>
    request("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password })
    }),
  signup: (name, email, password) =>
    request("/auth/register", {
      method: "POST",
      body: JSON.stringify({ name, email, password })
    }),
  logout: () => request("/auth/logout", { method: "POST" }),

  // Videos
  videos: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return request(`/videos${query ? `?${query}` : ""}`);
  },
  video: (id) => request(`/videos/${encodeURIComponent(id)}`),
  uploadVideo: (formData) =>
    request("/videos", { method: "POST", body: formData }),
  deleteVideo: (id) =>
    request(`/videos/${encodeURIComponent(id)}`, { method: "DELETE" }),

  // Video interactions
  like: (id) =>
    request(`/videos/${encodeURIComponent(id)}/like`, { method: "POST" }),
  star: (id) =>
    request(`/videos/${encodeURIComponent(id)}/star`, { method: "POST" }),
  starred: () => request("/users/me/starred"),

  // Account
  account: () => request("/users/me"),
  updateAccount: (details) =>
    request("/users/me", {
      method: "PATCH",
      body: JSON.stringify(details)
    })
};