import { mount } from "./mount";
import Forgot from "../pages/Forgot";

mount(Forgot);