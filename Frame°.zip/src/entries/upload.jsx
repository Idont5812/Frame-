import { mount } from "./mount";
import Upload from "../pages/Upload";

mount(Upload);