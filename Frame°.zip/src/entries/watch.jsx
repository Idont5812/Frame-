import { mount } from "./mount";
import Watch from "../pages/Watch";

mount(Watch);