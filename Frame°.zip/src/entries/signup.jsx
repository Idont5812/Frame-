import { mount } from "./mount";
import Signup from "../pages/Signup";

mount(Signup);