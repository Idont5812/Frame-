
import React from "react";
import { createRoot } from "react-dom/client";

import { AuthProvider } from "../components/AuthProvider";
import { ToastProvider } from "../components/Utilities";

import "../styles/global.css";

export function mount(Page) {
  const rootElement = document.getElementById("root");

  if (!rootElement) {
    throw new Error("Frame°: #root element not found.");
  }

  createRoot(rootElement).render(
    <React.StrictMode>
      <ToastProvider>
        <AuthProvider>
          <Page />
        </AuthProvider>
      </ToastProvider>
    </React.StrictMode>
  );
}
