import { mount } from "./mount";
import Starred from "../pages/Starred";

mount(Starred);