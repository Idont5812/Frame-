
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState
} from "react";

import { Check, X, AlertCircle, Info, Copy } from "lucide-react";

/* =================================
   TOAST NOTIFICATIONS
================================= */

const ToastContext = createContext(null);

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const nextId = useRef(1);

  const removeToast = useCallback((id) => {
    setToasts(current => current.filter(toast => toast.id !== id));
  }, []);

  const toast = useCallback((message, type = "info", duration = 3000) => {
    const id = nextId.current++;

    setToasts(current => [
      ...current,
      { id, message, type }
    ]);

    setTimeout(() => removeToast(id), duration);
  }, [removeToast]);

  return (
    <ToastContext.Provider value={toast}>
      {children}

      <div className="toast-container">
        {toasts.map(item => (
          <div className={`frame-toast toast-${item.type}`} key={item.id}>
            {item.type === "success" && <Check size={17} />}
            {item.type === "error" && <AlertCircle size={17} />}
            {item.type === "info" && <Info size={17} />}

            <span>{item.message}</span>

            <button
              className="toast-close"
              onClick={() => removeToast(item.id)}
              aria-label="Dismiss notification"
            >
              <X size={15} />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const context = useContext(ToastContext);

  if (!context) {
    throw new Error("useToast must be used inside ToastProvider");
  }

  return context;
}

/* =================================
   COPY TO CLIPBOARD
================================= */

export async function copyToClipboard(text) {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }

    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";

    document.body.appendChild(textarea);
    textarea.select();

    const successful = document.execCommand("copy");
    textarea.remove();

    return successful;
  } catch {
    return false;
  }
}

/* =================================
   RELATIVE TIMESTAMPS
================================= */

export function formatRelativeTime(dateValue) {
  if (!dateValue) return "";

  const date = new Date(dateValue);
  if (Number.isNaN(date.getTime())) return "";

  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);

  if (seconds < 0) {
    return date.toLocaleDateString();
  }

  if (seconds < 60) return "Just now";
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
  if (seconds < 2592000) return `${Math.floor(seconds / 604800)}w ago`;
  if (seconds < 31536000) return `${Math.floor(seconds / 2592000)}mo ago`;

  return `${Math.floor(seconds / 31536000)}y ago`;
}

/* =================================
   VIDEO SORTING
================================= */

export function sortVideos(videos = [], mode = "newest") {
  const list = [...videos];

  const getDate = video =>
    new Date(
      video.createdAt ||
      video.created_at ||
      video.uploadedAt ||
      0
    ).getTime() || 0;

  const getViews = video =>
    Number(video.views ?? video.view_count ?? 0);

  const getLikes = video =>
    Number(video.likes ?? video.likeCount ?? video.like_count ?? 0);

  switch (mode) {
    case "popular":
    case "views":
      return list.sort((a, b) => getViews(b) - getViews(a));

    case "liked":
    case "likes":
      return list.sort((a, b) => getLikes(b) - getLikes(a));

    case "oldest":
      return list.sort((a, b) => getDate(a) - getDate(b));

    case "newest":
    default:
      return list.sort((a, b) => getDate(b) - getDate(a));
  }
}

/* =================================
   CONFIRMATION DIALOG
================================= */

export function ConfirmDialog({
  open,
  title = "Are you sure?",
  message = "This action cannot be undone.",
  confirmText = "Confirm",
  cancelText = "Cancel",
  danger = false,
  onConfirm,
  onCancel
}) {
  useEffect(() => {
    if (!open) return;

    const handleKey = event => {
      if (event.key === "Escape") onCancel?.();
    };

    window.addEventListener("keydown", handleKey);

    return () => window.removeEventListener("keydown", handleKey);
  }, [open, onCancel]);

  if (!open) return null;

  return (
    <div
      className="confirm-backdrop"
      onMouseDown={event => {
        if (event.target === event.currentTarget) onCancel?.();
      }}
    >
      <section
        className="confirm-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="confirm-title"
      >
        <h3 id="confirm-title">{title}</h3>
        <p>{message}</p>

        <div className="confirm-actions">
          <button
            className="btn-secondary"
            onClick={onCancel}
          >
            {cancelText}
          </button>

          <button
            className={danger ? "btn-danger" : "btn-primary"}
            onClick={onConfirm}
          >
            {confirmText}
          </button>
        </div>
      </section>
    </div>
  );
}
