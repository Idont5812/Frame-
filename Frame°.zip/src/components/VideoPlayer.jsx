import { useRef, useState } from "react";
import {
  Play, Pause, Volume2, VolumeX, Maximize,
  Minimize, Settings, Theater
} from "lucide-react";

export default function VideoPlayer({ src, poster, onEnded }) {
  const videoRef = useRef(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [theater, setTheater] = useState(false);

  async function togglePlay() {
    const video = videoRef.current;
    if (!video) return;

    if (video.paused) {
      try {
        await video.play();
        setPlaying(true);
      } catch {
        setPlaying(false);
      }
    } else {
      video.pause();
      setPlaying(false);
    }
  }

  function toggleFullscreen() {
    const video = videoRef.current;
    if (!video) return;

    if (document.fullscreenElement) {
      document.exitFullscreen?.();
    } else {
      video.parentElement?.requestFullscreen?.();
    }
  }

  return (
    <div className={`player-wrap ${theater ? "player-theater" : ""}`}>
      <video
        ref={videoRef}
        className="frame-player"
        src={src}
        poster={poster}
        playsInline
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onEnded={onEnded}
      />

      <div className="player-controls">
        <button onClick={togglePlay} aria-label={playing ? "Pause" : "Play"}>
          {playing ? <Pause size={19} /> : <Play size={19} />}
        </button>

        <button
          onClick={() => {
            const video = videoRef.current;
            if (!video) return;
            video.muted = !video.muted;
            setMuted(video.muted);
          }}
          aria-label={muted ? "Unmute" : "Mute"}
        >
          {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
        </button>

        <span className="player-spacer" />

        <button
          onClick={() => setTheater((value) => !value)}
          aria-label="Toggle theater mode"
        >
          <Theater size={18} />
        </button>

        <button
          onClick={toggleFullscreen}
          aria-label="Toggle fullscreen"
        >
          {document.fullscreenElement
            ? <Minimize size={18} />
            : <Maximize size={18} />}
        </button>
      </div>
    </div>
  );
}