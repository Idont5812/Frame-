import Header from "./Header";
import { useAuth } from "./AuthProvider";

export default function AppShell({ children, onSearch }) {
  const { user } = useAuth();

  return (
    <div className="app-shell">
      <Header user={user} onSearch={onSearch} />
      <main className="page-content">{children}</main>
    </div>
  );
}