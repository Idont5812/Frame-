import { useState } from "react";
import { UserRound, Menu, X, Upload, Bookmark } from "lucide-react";
import Dock from "./Dock";

export default function Header({ onSearch, user }) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="site-header">
      <a className="wordmark" href="/">
        Frame<span>°</span>
      </a>

      <Dock onSearch={onSearch} />

      <nav className={`header-nav ${menuOpen ? "header-nav-open" : ""}`}>
        <a href="/pages/starred.html">
          <Bookmark size={16} />
          <span>Starred</span>
        </a>

        <a href="/pages/upload.html">
          <Upload size={16} />
          <span>Upload</span>
        </a>

        <a className="account-link" href={user ? "/pages/account.html" : "/pages/login.html"}>
          <UserRound size={17} />
          <span>{user?.name || "Sign in"}</span>
        </a>
      </nav>

      <button
        className="mobile-menu-button"
        onClick={() => setMenuOpen((open) => !open)}
        aria-label={menuOpen ? "Close menu" : "Open menu"}
      >
        {menuOpen ? <X size={21} /> : <Menu size={21} />}
      </button>
    </header>
  );
}