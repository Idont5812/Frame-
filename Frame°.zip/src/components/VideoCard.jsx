import { Eye, Heart, Star } from "lucide-react";

export default function VideoCard({ video }) {
  const id = video.id;
  const title = video.title || "Untitled video";

  return (
    <a
      className="video-card"
      href={`/pages/watch.html?id=${encodeURIComponent(id)}`}
    >
      <div className="video-thumbnail">
        <img
          src={video.thumbnail || "/placeholder-thumbnail.svg"}
          alt=""
          loading="lazy"
        />

        <span className="video-duration">
          {video.duration || "0:00"}
        </span>

        <div className="thumbnail-overlay">
          <span>WATCH VIDEO</span>
        </div>
      </div>

      <div className="video-card-info">
        <div className="video-card-heading">
          <h3 title={title}>{title}</h3>

          {video.starred && (
            <Star className="video-starred-icon" size={15} fill="currentColor" />
          )}
        </div>

        <p className="video-uploader">
          {video.uploader || video.uploaderName || "Frame° creator"}
        </p>

        <div className="video-metadata">
          <span><Eye size={13} /> {video.views ?? 0}</span>
          <span><Heart size={13} /> {video.likes ?? 0}</span>
          <span>{video.uploadedAt || video.date || "Recently uploaded"}</span>
        </div>
      </div>
    </a>
  );
}