import { useState } from "react";
import { Search, X, Radio, ArrowUpRight } from "lucide-react";

export default function Dock({ onSearch }) {
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");

  function submitSearch(event) {
    event.preventDefault();
    onSearch?.(query.trim());
  }

  return (
    <div className={`live-dock ${searchOpen ? "live-dock-search" : ""}`}>
      {!searchOpen ? (
        <>
          <div className="dock-status">
            <span className="live-dot" />
            <span className="dock-label">LIVE UPDATES</span>
            <span className="dock-separator">·</span>
            <span className="dock-message">Your feed is ready</span>
          </div>

          <button
            className="dock-icon-button"
            aria-label="Search videos"
            onClick={() => setSearchOpen(true)}
          >
            <Search size={17} strokeWidth={1.8} />
          </button>
        </>
      ) : (
        <form className="dock-search-form" onSubmit={submitSearch}>
          <Search size={17} />
          <input
            autoFocus
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search your video space..."
            aria-label="Search videos"
          />
          <button className="dock-submit" type="submit" aria-label="Submit search">
            <ArrowUpRight size={17} />
          </button>
          <button
            className="dock-icon-button"
            type="button"
            aria-label="Close search"
            onClick={() => {
              setSearchOpen(false);
              setQuery("");
            }}
          >
            <X size={17} />
          </button>
        </form>
      )}
    </div>
  );
}