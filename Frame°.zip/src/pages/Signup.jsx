import { useState } from "react";
import { ArrowRight, UserRoundPlus } from "lucide-react";
import { api } from "../services/api";
import { useAuth } from "../components/AuthProvider";

export default function Signup() {
  const { refreshUser } = useAuth();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setError("");
    setBusy(true);

    try {
      await api.signup(name, email, password);
      await refreshUser();
      window.location.href = "/";
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth-page">
      <a className="wordmark auth-logo" href="/">Frame<span>°</span></a>

      <main className="auth-card">
        <div className="auth-icon"><UserRoundPlus size={21} /></div>
        <p className="page-eyebrow">MAKE YOURSELF AT HOME</p>
        <h1>Your space starts here.</h1>
        <p className="auth-description">Create an account and make Frame° yours.</p>

        <form onSubmit={submit}>
          <div className="form-field">
            <label htmlFor="name">Display name</label>
            <input
              id="name"
              autoComplete="name"
              required
              maxLength={40}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="What should we call you?"
            />
          </div>

          <div className="form-field">
            <label htmlFor="email">Email address</label>
            <input
              id="email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
            />
          </div>

          <div className="form-field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              autoComplete="new-password"
              minLength={8}
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="At least 8 characters"
            />
          </div>

          {error && <p className="error-message">{error}</p>}

          <button className="primary-button auth-submit" disabled={busy}>
            {busy ? "Creating account..." : "Create account"}
            <ArrowRight size={16} />
          </button>
        </form>

        <p className="auth-switch">
          Already have an account? <a href="/pages/login.html">Sign in</a>
        </p>
      </main>

      <p className="auth-footer">YOUR PERSONAL VIDEO SPACE</p>
    </div>
  );
}