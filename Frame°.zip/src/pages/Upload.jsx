import { useState } from "react";
import { UploadCloud, Film, ImagePlus } from "lucide-react";
import AppShell from "../components/AppShell";
import { api } from "../services/api";
import { useAuth } from "../components/AuthProvider";

export default function Upload() {
  const { user, loading } = useAuth();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [videoFile, setVideoFile] = useState(null);
  const [thumbnailFile, setThumbnailFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  async function submit(event) {
    event.preventDefault();
    setError("");
    setSuccess("");

    if (!videoFile) {
      setError("Choose a video file first.");
      return;
    }

    const form = new FormData();
    form.append("title", title);
    form.append("description", description);
    form.append("video", videoFile);

    if (thumbnailFile) {
      form.append("thumbnail", thumbnailFile);
    }

    setBusy(true);

    try {
      const result = await api.uploadVideo(form);
      setSuccess("Your video has been uploaded.");
      setTitle("");
      setDescription("");
      setVideoFile(null);
      setThumbnailFile(null);

      if (result.video?.id) {
        window.location.href = `/pages/watch.html?id=${encodeURIComponent(result.video.id)}`;
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  if (loading) {
    return <AppShell><div className="empty-state"><p>Loading your studio...</p></div></AppShell>;
  }

  if (!user) {
    return (
      <AppShell>
        <div className="empty-state">
          <UploadCloud size={24} />
          <h3>Sign in to upload</h3>
          <p>Your creator studio is available after signing in.</p>
          <a className="primary-button" href="/pages/login.html">Sign in</a>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <p className="page-eyebrow">CREATOR STUDIO</p>
      <h1 className="page-title">Put it out there.</h1>
      <p className="page-subtitle">Give your next video a place to live.</p>

      <form className="upload-form" onSubmit={submit}>
        <label className="upload-dropzone" htmlFor="video-file">
          <Film size={28} />
          <strong>{videoFile ? videoFile.name : "Choose your video"}</strong>
          <span>{videoFile ? "Video selected" : "Select a video file from your device"}</span>
          <input
            id="video-file"
            type="file"
            accept="video/*"
            onChange={(e) => setVideoFile(e.target.files?.[0] || null)}
          />
        </label>

        <div className="form-field">
          <label htmlFor="title">Video title</label>
          <input
            id="title"
            required
            maxLength={120}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Give your video a title"
          />
        </div>

        <div className="form-field">
          <label htmlFor="description">Description</label>
          <textarea
            id="description"
            maxLength={3000}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="What's this video about?"
          />
        </div>

        <label className="thumbnail-picker" htmlFor="thumbnail-file">
          <ImagePlus size={19} />
          <span>{thumbnailFile ? thumbnailFile.name : "Choose a custom thumbnail (optional)"}</span>
          <input
            id="thumbnail-file"
            type="file"
            accept="image/*"
            onChange={(e) => setThumbnailFile(e.target.files?.[0] || null)}
          />
        </label>

        {error && <p className="error-message">{error}</p>}
        {success && <p className="success-message">{success}</p>}

        <button className="primary-button" disabled={busy}>
          <UploadCloud size={16} />
          {busy ? "Uploading..." : "Upload video"}
        </button>
      </form>
    </AppShell>
  );
}