import { useEffect, useState } from "react";
import { UserRound, LogOut, Video, Star, Eye } from "lucide-react";
import AppShell from "../components/AppShell";
import { api } from "../services/api";
import { useAuth } from "../components/AuthProvider";

export default function Account() {
  const { user, loading, logout } = useAuth();
  const [stats, setStats] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!loading && user) {
      api.account()
        .then((result) => setStats(result.stats || {}))
        .catch((err) => setError(err.message));
    }
  }, [user, loading]);

  async function signOut() {
    try {
      await logout();
      window.location.href = "/";
    } catch (err) {
      setError(err.message);
    }
  }

  if (loading) {
    return <AppShell><div className="empty-state"><p>Loading account...</p></div></AppShell>;
  }

  if (!user) {
    return (
      <AppShell>
        <div className="empty-state">
          <UserRound size={24} />
          <h3>Your account lives here</h3>
          <p>Sign in to view your profile and library.</p>
          <a className="primary-button" href="/pages/login.html">Sign in</a>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <p className="page-eyebrow">YOUR FRAME°</p>
      <h1 className="page-title">Your space.</h1>
      <p className="page-subtitle">Your profile, uploads, and saved videos.</p>

      <section className="account-profile">
        <div className="account-avatar">
          {(user.name || "F").charAt(0).toUpperCase()}
        </div>
        <div className="account-identity">
          <h2>{user.name}</h2>
          <p>{user.email}</p>
        </div>
        <button className="secondary-button account-logout" onClick={signOut}>
          <LogOut size={15} />
          Sign out
        </button>
      </section>

      <div className="account-stats">
        <div className="account-stat">
          <Video size={18} />
          <strong>{stats?.uploads ?? "—"}</strong>
          <span>Uploads</span>
        </div>
        <div className="account-stat">
          <Star size={18} />
          <strong>{stats?.starred ?? "—"}</strong>
          <span>Starred</span>
        </div>
        <div className="account-stat">
          <Eye size={18} />
          <strong>{stats?.views ?? "—"}</strong>
          <span>Video views</span>
        </div>
      </div>

      {error && <p className="error-message">{error}</p>}

      <div className="account-links">
        <a href="/pages/upload.html">Open Creator Studio <span>→</span></a>
        <a href="/pages/starred.html">View starred videos <span>→</span></a>
      </div>
    </AppShell>
  );
}