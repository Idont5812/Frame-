import { useState } from "react";
import { ArrowRight, LockKeyhole } from "lucide-react";
import { api } from "../services/api";
import { useAuth } from "../components/AuthProvider";

export default function Login() {
  const { refreshUser } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setError("");
    setBusy(true);

    try {
      await api.login(email, password);
      await refreshUser();
      window.location.href = "/";
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth-page">
      <a className="wordmark auth-logo" href="/">Frame<span>°</span></a>

      <main className="auth-card">
        <div className="auth-icon"><LockKeyhole size={21} /></div>
        <p className="page-eyebrow">WELCOME BACK</p>
        <h1>Pick up where you left off.</h1>
        <p className="auth-description">Sign in to return to your personal video space.</p>

        <form onSubmit={submit}>
          <div className="form-field">
            <label htmlFor="email">Email address</label>
            <input
              id="email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
            />
          </div>

          <div className="form-field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Your password"
            />
          </div>

          <div className="auth-forgot">
            <a href="/pages/forgot.html">Forgot password?</a>
          </div>

          {error && <p className="error-message">{error}</p>}

          <button className="primary-button auth-submit" disabled={busy}>
            {busy ? "Signing in..." : "Sign in"}
            <ArrowRight size={16} />
          </button>
        </form>

        <p className="auth-switch">
          New to Frame°? <a href="/pages/signup.html">Create an account</a>
        </p>
      </main>

      <p className="auth-footer">YOUR PERSONAL VIDEO SPACE</p>
    </div>
  );
}