import { useCallback, useEffect, useState } from "react";
import { Compass, Sparkles, RefreshCw } from "lucide-react";
import AppShell from "../components/AppShell";
import VideoCard from "../components/VideoCard";
import { api } from "../services/api";

export default function Home() {
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");

  const loadVideos = useCallback(async (query = "") => {
    setLoading(true);
    setError("");

    try {
      const result = await api.videos(query ? { search: query } : {});
      setVideos(result.videos || []);
    } catch (err) {
      setError(err.message || "Couldn't load your feed.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadVideos();
  }, [loadVideos]);

  function handleSearch(query) {
    setSearch(query);
    loadVideos(query);
  }

  return (
    <AppShell onSearch={handleSearch}>
      <section className="home-intro">
        <p className="page-eyebrow">YOUR PERSONAL VIDEO SPACE</p>
        <h1 className="page-title">A little more you.</h1>
        <p className="page-subtitle">
          Pick up where curiosity takes you.
        </p>
      </section>

      <section className="feed-section">
        <div className="section-heading">
          <div>
            <div className="section-kicker">
              <Compass size={15} />
              <span>{search ? "SEARCH RESULTS" : "YOUR FEED"}</span>
            </div>
            <h2>{search ? `Results for “${search}”` : "Explore videos"}</h2>
          </div>

          <button
            className="secondary-button"
            onClick={() => loadVideos(search)}
            disabled={loading}
          >
            <RefreshCw size={14} />
            Refresh
          </button>
        </div>

        {loading ? (
          <div className="empty-state">
            <Sparkles size={22} />
            <h3>Preparing your feed</h3>
            <p>Finding videos for your space...</p>
          </div>
        ) : error ? (
          <div className="empty-state">
            <h3>Feed unavailable</h3>
            <p>{error}</p>
            <button className="primary-button" onClick={() => loadVideos(search)}>
              Try again
            </button>
          </div>
        ) : videos.length ? (
          <div className="video-grid">
            {videos.map((video) => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <Sparkles size={22} />
            <h3>{search ? "No matching videos" : "Your feed is waiting"}</h3>
            <p>
              {search
                ? "Try another search term."
                : "Videos will appear here when they're uploaded."}
            </p>
          </div>
        )}
      </section>
    </AppShell>
  );
}