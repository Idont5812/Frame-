import { useState } from "react";
import { ArrowLeft, Mail } from "lucide-react";

export default function Forgot() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  function submit(event) {
    event.preventDefault();
    setMessage("Password reset emails are not configured yet. Contact the site administrator for account help.");
  }

  return (
    <div className="auth-page">
      <a className="wordmark auth-logo" href="/">Frame<span>°</span></a>

      <main className="auth-card">
        <div className="auth-icon"><Mail size={21} /></div>
        <p className="page-eyebrow">ACCOUNT RECOVERY</p>
        <h1>Let's get you back in.</h1>
        <p className="auth-description">
          Enter the email address associated with your Frame° account.
        </p>

        <form onSubmit={submit}>
          <div className="form-field">
            <label htmlFor="email">Email address</label>
            <input
              id="email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
            />
          </div>

          {message && <p className="error-message">{message}</p>}

          <button className="primary-button auth-submit">
            Request password reset
          </button>
        </form>

        <p className="auth-switch">
          <a href="/pages/login.html"><ArrowLeft size={13} /> Back to sign in</a>
        </p>
      </main>

      <p className="auth-footer">YOUR PERSONAL VIDEO SPACE</p>
    </div>
  );
}