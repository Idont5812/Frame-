import { useEffect, useState } from "react";
import { Star } from "lucide-react";
import AppShell from "../components/AppShell";
import VideoCard from "../components/VideoCard";
import { api } from "../services/api";
import { useAuth } from "../components/AuthProvider";

export default function Starred() {
  const { user, loading: authLoading } = useAuth();
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (authLoading) return;

    if (!user) {
      setLoading(false);
      return;
    }

    api.starred()
      .then((result) => setVideos(result.videos || []))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [user, authLoading]);

  return (
    <AppShell>
      <p className="page-eyebrow">YOUR COLLECTION</p>
      <h1 className="page-title">Kept close.</h1>
      <p className="page-subtitle">The videos you decided to keep around.</p>

      {authLoading || loading ? (
        <div className="empty-state"><p>Loading your collection...</p></div>
      ) : !user ? (
        <div className="empty-state">
          <Star size={23} />
          <h3>Your collection awaits</h3>
          <p>Sign in to see your starred videos.</p>
          <a className="primary-button" href="/pages/login.html">Sign in</a>
        </div>
      ) : error ? (
        <div className="empty-state"><p>{error}</p></div>
      ) : videos.length ? (
        <div className="video-grid">
          {videos.map((video) => (
            <VideoCard key={video.id} video={{ ...video, starred: true }} />
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <Star size={23} />
          <h3>Nothing starred yet</h3>
          <p>Star videos you want to find easily later.</p>
          <a className="secondary-button" href="/">Explore videos</a>
        </div>
      )}
    </AppShell>
  );
}