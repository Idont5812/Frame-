import { useEffect, useState } from "react";
import {
  ArrowLeft, Heart, Star, Eye, CalendarDays,
  Share2, PlayCircle
} from "lucide-react";
import AppShell from "../components/AppShell";
import VideoPlayer from "../components/VideoPlayer";
import VideoCard from "../components/VideoCard";
import { api } from "../services/api";
import { useAuth } from "../components/AuthProvider";

export default function Watch() {
  const id = new URLSearchParams(window.location.search).get("id");
  const { user } = useAuth();

  const [video, setVideo] = useState(null);
  const [related, setRelated] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!id) {
      setError("No video was selected.");
      setLoading(false);
      return;
    }

    let active = true;

    async function load() {
      try {
        const result = await api.video(id);
        if (!active) return;

        setVideo(result.video || null);
        setRelated(result.related || []);
      } catch (err) {
        if (active) setError(err.message);
      } finally {
        if (active) setLoading(false);
      }
    }

    load();
    return () => {
      active = false;
    };
  }, [id]);

  async function interact(action) {
    if (!user) {
      window.location.href = "/pages/login.html";
      return;
    }

    if (busy || !video) return;
    setBusy(true);

    try {
      const result = await action(video.id);
      setVideo((current) => ({ ...current, ...result.video }));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function shareVideo() {
    const url = window.location.href;

    try {
      if (navigator.share) {
        await navigator.share({ title: video.title, url });
      } else {
        await navigator.clipboard.writeText(url);
      }
    } catch {
      // The user may cancel the share dialog.
    }
  }

  if (loading) {
    return (
      <AppShell>
        <div className="empty-state">
          <PlayCircle size={22} />
          <h3>Loading video</h3>
          <p>Getting everything ready...</p>
        </div>
      </AppShell>
    );
  }

  if (error || !video) {
    return (
      <AppShell>
        <div className="empty-state">
          <h3>Video unavailable</h3>
          <p>{error || "This video could not be found."}</p>
          <a className="primary-button" href="/">Back to home</a>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <a className="back-link" href="/">
        <ArrowLeft size={15} />
        Back to feed
      </a>

      <div className="watch-layout">
        <main className="watch-main">
          <VideoPlayer
            src={video.videoUrl || video.video_url}
            poster={video.thumbnail}
          />

          <div className="watch-title-row">
            <div>
              <p className="page-eyebrow">NOW PLAYING</p>
              <h1 className="watch-title">{video.title}</h1>
            </div>
          </div>

          <div className="watch-info-row">
            <div className="watch-creator">
              <div className="creator-avatar">
                {(video.uploader || "F").charAt(0).toUpperCase()}
              </div>
              <div>
                <strong>{video.uploader || "Frame° creator"}</strong>
                <span>Creator</span>
              </div>
            </div>

            <div className="watch-actions">
              <button
                className={`secondary-button ${video.liked ? "is-active" : ""}`}
                disabled={busy}
                onClick={() => interact(api.like)}
              >
                <Heart size={15} fill={video.liked ? "currentColor" : "none"} />
                {video.likes ?? 0}
              </button>

              <button
                className={`secondary-button ${video.starred ? "is-active" : ""}`}
                disabled={busy}
                onClick={() => interact(api.star)}
              >
                <Star size={15} fill={video.starred ? "currentColor" : "none"} />
                {video.starred ? "Starred" : "Star"}
              </button>

              <button className="secondary-button" onClick={shareVideo}>
                <Share2 size={15} />
                Share
              </button>
            </div>
          </div>

          <div className="watch-stats">
            <span><Eye size={14} /> {video.views ?? 0} views</span>
            <span><CalendarDays size={14} /> {video.uploadedAt || video.date || "Recently uploaded"}</span>
          </div>

          {video.description && (
            <div className="video-description">
              {video.description}
            </div>
          )}

          {error && <p className="error-message">{error}</p>}
        </main>

        <aside className="watch-sidebar">
          <p className="page-eyebrow">KEEP EXPLORING</p>
          <h2>Up next</h2>

          {related.length ? (
            <div className="related-list">
              {related.map((item) => (
                <VideoCard key={item.id} video={item} />
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <p>No other videos yet.</p>
            </div>
          )}
        </aside>
      </div>
    </AppShell>
  );
}